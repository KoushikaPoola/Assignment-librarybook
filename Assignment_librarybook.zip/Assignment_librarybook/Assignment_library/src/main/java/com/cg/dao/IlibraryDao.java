package com.cg.dao;

import java.util.List;
import com.cg.beans.Book;
import com.cg.beans.Library;

public interface IlibraryDao {
	
	public void addBook(Book bo) ;
	public Library getLibrary(String libraName);
	public Book getBookbyId(int bookId);
	public void deleteBook(int bookId);
        public Book updateBookData(int id,String bookname,String auth,String publi);
	public List<Book> getAllBooks();
}

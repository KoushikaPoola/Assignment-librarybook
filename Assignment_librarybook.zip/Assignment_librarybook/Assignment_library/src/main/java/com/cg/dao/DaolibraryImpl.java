package com.cg.dao;

import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;

import com.cg.beans.Book;
import com.cg.beans.Library;

public class DaolibraryImpl implements IlibraryDao{
	
	private static EntityManagerFactory mag = Persistence.createEntityManagerFactory("Jpa-servletdemo");
	private static EntityManager em = mag.createEntityManager();

	@Override
	public void addBook(Book bo) {
		em.getTransaction().begin();
		em.persist(bo);
		em.getTransaction().commit();
	}

	@Override
        public Library getLibrary(String libraName) {
		EntityManager em1 = mag.createEntityManager();
		TypedQuery<Library> q = em1.createQuery("SELECT lib FROM Library lib", Library.class);
		List<Library> libra = q.getResultList();
		
		for(Library lib : libra ) {
			if(lib.getLibraryName().equals(libraName)) {
				return lib;
			}
		}
		return null;
	}

	@Override
	public Book getBookbyId(int bookId) {
		return em.getBookbyId(Book.class,bookId);
	}

        @Override
	public void deleteBook(int bookId) {
		em.getTransaction().begin();
		Book bo = getBookbyId(bookId);
		em.remove(bo);
		em.getTransaction().commit();
	}

	@Override
        public Book updateBookData(int id,String bookname,String auth,String publi) {
		Book bo = getBookbyId(id);
		em.getTransaction().begin();
		if(bookname.length()!=0) {
			bo.setBookName(bookname);
		}
		if(auth.length()!=0) {
			bo.setAuthor(auth);
		}
		if(publi.length()!=0) {
			bo.setPublisher(publi);
		}
		em.getTransaction().commit();
		return bo;
	}

        @Override
	public List<Book> getAllBooks(){
		EntityManager em1 = mag.createEntityManager();
		TypedQuery<Book> q1 = em.createQuery("SELECT bo FROM Book bo", Book.class);
		List<Book> books = q1.getResultList();
		em1.close();
		return books;
	}
	
}

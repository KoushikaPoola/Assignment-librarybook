package com.cg.controllers;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.dao.DaolibraryImpl;
import com.cg.beans.Book;

public class getBookbyId extends HttpServlet {

	private static final long serialVersionUID = 1L;
	DaolibraryImpl dao = new DaolibraryImpl();
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out = response.getWriter();
		response.setContentType("text/html");

		Book bo = dao.getBookbyId(Integer.parseInt(request.getParameter("getboid")));
		if(bo!=null) {
			out.println("Book Id : "+bo.getBookId());
			out.println("Book Name : "+bo.getBookName());
			out.println("Author of Book : "+bo.getAuthor());
			out.println("Publisher of Book : "+bo.getPublisher());
		}else {
			out.println("Enter valid bookid...");
		}
	}

}

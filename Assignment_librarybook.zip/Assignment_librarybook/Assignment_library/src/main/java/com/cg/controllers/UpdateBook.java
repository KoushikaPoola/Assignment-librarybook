package com.cg.controllers;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.dao.DaolibraryImpl;
import com.cg.beans.Book;


public class UpdateBook extends HttpServlet {
	private static final long serialVersionUID = 1L;
        DaolibraryImpl dao = new DaolibraryImpl();

    	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    		PrintWriter out = response.getWriter();
    		response.setContentType("text/html");
    		
    		int boId = Integer.parseInt(request.getParameter("nwId"));
    		String newBoname = request.getParameter("nwName");
    		String newBoauth = request.getParameter("nwAuth");
    		String newBopub = request.getParameter("nwPub");
    		
    		Book book = dao.getBookbyId(boId);
    		
    	     out.println("<html>");
    		 out.println("<body>");
    			
                        out.println("Book Name : " +book.getBookName());out.print("<br>");
    		 	out.println("Book Author : "+book.getAuthor());out.print("<br>");
    		 	out.println("Book PublisherName : "+book.getPublisher());out.print("<br>");
    		 
    		Book nwbook = dao.updateBookData(boId,newBoname,newBoauth,newBopub);
    		 	
    			out.println("------------updated Book Data------------ ");out.print("<br>");out.print("<br>");
    			out.println("Book Name : " +nwbook.getBookName());out.print("<br>");
    			out.println("Book Author : "+nwbook.getAuthor());out.print("<br>");
    			out.println("Book Publisher Name : "+nwbook.getPublisher());out.print("<br>");
    			
    		out.println("</html>");
    		out.println("</body>");
	}

}
